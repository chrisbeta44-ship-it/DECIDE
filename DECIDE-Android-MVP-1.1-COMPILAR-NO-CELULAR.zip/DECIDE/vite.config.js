import { defineConfig } from 'vite';
export default defineConfig({ publicDir: 'www', server: { host: '0.0.0.0' } });