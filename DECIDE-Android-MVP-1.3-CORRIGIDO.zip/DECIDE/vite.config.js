import { defineConfig } from 'vite';
export default defineConfig({ base: './', publicDir: 'www', server: { host: '0.0.0.0' } });
