# DECIDE! — primeira versão Android

Aplicativo em português, visual escuro/tecnológico. A roleta funciona localmente e sem internet. O assistente de IA tem a interface pronta, mas exige um backend HTTPS configurado; nenhuma chave de API deve ser colocada no app.

## O que já funciona
- Categorias: filmes, comida, onde ir, casal e decisões.
- Opções personalizadas e sorteio aleatório.
- Histórico local no aparelho.
- Favoritar resultado (armazenamento local).
- Modo casal com ideias e desafios consensuais.
- Catálogo adulto com nomes de posições, filtro de dificuldade e preferência de acessórios; sem imagens.
- Interface adaptada para celular.
- Cache offline básico via service worker quando executado como PWA.

## Gerar APK no computador
É necessário Node.js LTS, Android Studio e Android SDK.

1. Extraia o ZIP.
2. Abra a pasta `DECIDE` no terminal.
3. Execute:
   ```bash
   npm install
   npm run build
   npx cap add android
   npx cap sync android
   npx cap open android
   ```
4. No Android Studio, aguarde a sincronização do Gradle.
5. Para gerar APK de teste: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de debug ficará normalmente em `android/app/build/outputs/apk/debug/app-debug.apk`.

Para atualizar o app após mudanças no código:
```bash
npm run android:sync
```

## Testar no navegador
```bash
npm install
npm run dev
```
Abra o endereço local exibido pelo Vite. Para testar em outro aparelho na mesma rede, use o endereço de rede local mostrado no terminal.

## Gerar APK pelo próprio celular
A compilação Android nativa exige ferramentas de build e costuma ser mais simples em um computador com Android Studio. No celular, é possível testar a versão web/PWA pelo navegador. Não é necessário instalar nada para experimentar a roleta em modo web.

## Estrutura
- `www/`: interface, estilos, manifest, cache offline.
- `server/`: orientação para conectar a IA com segurança.
- `capacitor.config.json`: identificação do app Android (`com.decide.app`).

## Limitações desta versão
- O projeto entregue é o código-fonte pronto para gerar o projeto Android via Capacitor; não contém um APK já compilado.
- A IA ainda não tem backend conectado.
- Filmes, locais e recomendações reais exigirão fontes de dados/serviços próprios em uma etapa posterior.
- O armazenamento de histórico e favoritos é local e não sincroniza entre aparelhos.
