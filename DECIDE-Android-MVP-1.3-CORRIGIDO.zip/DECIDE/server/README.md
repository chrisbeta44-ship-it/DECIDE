# Backend da IA (opcional nesta primeira compilação)

O aplicativo não deve conter uma chave de API dentro do APK. Para ativar a IA, publique um backend HTTPS que receba `POST /api/assistant` com `{ "message": "...", "context": {} }` e devolva `{ "reply": "..." }`.

O frontend já chama `/api/assistant`. Em desenvolvimento, configure um proxy no Vite ou hospede frontend e endpoint no mesmo domínio. O backend deve:
- manter a chave de IA somente em variável de ambiente;
- validar tamanho e conteúdo da mensagem;
- aplicar limite de uso por IP/conta;
- não armazenar conversas sem consentimento;
- informar claramente que respostas da IA podem conter erros.

A IA não está ativa até esse endpoint ser implementado e publicado. A roleta funciona sem internet.
