import './style.css';

const categories = {
  'Filmes': ['Comédia','Ação','Terror','Romance','Suspense'],
  'Comida': ['Pizza','Hambúrguer','Japonês','Churrasco','Massas'],
  'Onde ir': ['Cinema','Restaurante','Parque','Barzinho','Ficar em casa'],
  'A dois': ['Noite romântica','Massagem','Jogo de perguntas','Encontro surpresa','Filme juntos'],
  'Decisões': ['Sair','Ficar em casa','Fazer algo novo','Descansar','Passear']
};
let selected = 'Filmes';
let lastResult = '';
let history = JSON.parse(localStorage.getItem('decide-history') || '[]');
let favorites = JSON.parse(localStorage.getItem('decide-favorites') || '[]');

const app = document.querySelector('#app');
app.innerHTML = `
  <main class="shell">
    <header class="top"><div><div class="brand">DECIDE<span>!</span></div><div class="tag">YOUR LIFE. YOUR CHOICE.</div></div><div class="spark">✦</div></header>
    <section class="hero"><div class="eyebrow">SEU ASSISTENTE DE DECISÕES</div><h1>A dúvida<br>acaba <span>aqui.</span></h1><p>Escolha, sorteie ou converse com a inteligência artificial.</p></section>
    <nav class="tabs"><button class="tab active" data-tab="roulette">🎲 Roleta</button><button class="tab" data-tab="ai">✦ Assistente IA</button><button class="tab" data-tab="couple">♥ Modo casal</button></nav>
    <section id="roulette" class="panel">
      <div class="section-head"><div><div class="eyebrow">01 / DEIXE A SORTE ESCOLHER</div><h2>Roleta de decisões</h2></div><span class="offline">● OFFLINE</span></div>
      <div class="chips">${Object.keys(categories).map(c=>`<button class="chip ${c===selected?'chosen':''}" data-category="${c}">${c}</button>`).join('')}</div>
      <label for="options">Suas opções <small>(uma por linha)</small></label>
      <textarea id="options" rows="5">${categories[selected].join('\n')}</textarea>
      <button id="spin" class="primary"><span>⟳</span> GIRAR A ROLETA</button>
      <div id="result" class="result hidden"><div class="eyebrow">O DECIDE! ESCOLHEU</div><div id="winner" class="winner"></div><div class="result-actions"><button id="again" class="secondary">Sortear novamente</button><button id="save" class="secondary">♡ Favoritar</button></div></div>
      <div class="mini-note">A roleta funciona sem internet. Suas opções ficam salvas neste aparelho.</div>
    </section>
    <section id="ai" class="panel hidden">
      <div class="section-head"><div><div class="eyebrow">02 / PENSE JUNTO</div><h2>Converse com a IA</h2></div><span class="online">● ONLINE</span></div>
      <div class="ai-intro"><div class="ai-icon">✦</div><div><b>Seu conselheiro de decisões</b><p>Conte o que está acontecendo. A IA ajuda a organizar ideias, comparar opções e encontrar possibilidades.</p></div></div>
      <div id="chat" class="chat"><div class="bubble bot">Oi! Qual decisão está difícil hoje? Posso ajudar a pensar sem escolher por você. 😊</div></div>
      <form id="ask"><textarea id="prompt" rows="3" placeholder="Ex.: Queremos sair hoje, temos R$100 e não sabemos para onde ir..."></textarea><button class="primary">ENVIAR PARA IA ↗</button></form>
      <div class="mini-note">A conversa com IA precisa de internet e de uma conexão segura com um servidor. Não coloque chaves de API neste aplicativo.</div>
    </section>
    <section id="couple" class="panel hidden">
      <div class="section-head"><div><div class="eyebrow">03 / ESCOLHAM JUNTOS</div><h2>Modo casal ♥</h2></div><span class="offline">PRIVADO</span></div>
      <div class="couple-card"><div class="couple-emoji">♥</div><h3>Uma experiência a dois</h3><p>Ideias românticas, perguntas para se conhecer melhor e desafios com respeito aos limites de cada pessoa.</p></div>
      <div class="couple-grid">
        <button class="idea" data-idea="Perguntas para se conhecer melhor">💬<b>Perguntas íntimas</b><small>Conversem e descubram algo novo</small></button>
        <button class="idea" data-idea="Desafios românticos">✨<b>Desafio romântico</b><small>Uma surpresa para os dois</small></button>
        <button class="idea" data-idea="Noite de conexão">🌙<b>Noite especial</b><small>Ideias para sair da rotina</small></button>
        <button class="idea" data-idea="Desafios adultos consensuais">🔒<b>Adultos</b><small>Somente com consentimento mútuo</small></button>
      </div>
      <div class="position-box">
        <div class="eyebrow">CATÁLOGO ADULTO • NOMES, SEM ILUSTRAÇÕES</div>
        <h3>Posições para casal</h3>
        <p>Lista informativa para adultos. Escolham juntos, conversem sobre conforto e respeitem os limites de cada pessoa.</p>
        <div class="position-controls">
          <select id="difficulty-filter" aria-label="Filtrar por dificuldade">
            <option value="Todas">Todas as dificuldades</option>
            <option value="Fácil">Fácil</option>
            <option value="Intermediária">Intermediária</option>
            <option value="Avançada">Avançada</option>
          </select>
          <select id="toy-filter" aria-label="Preferência de acessórios">
            <option value="Qualquer">Acessórios: qualquer opção</option>
            <option value="Sim">Considerar acessório</option>
            <option value="Não">Sem acessório</option>
          </select>
        </div>
        <div id="positions-list" class="positions-list"></div>
      </div>
      <div id="couple-output" class="bubble bot hidden"></div>
    </section>
    <section class="panel">
      <div class="section-head"><div><div class="eyebrow">SEU ESPAÇO</div><h2>Salvos recentemente</h2></div><button id="clear-history" class="text-btn">Limpar</button></div>
      <div id="history" class="history"></div>
    </section>
    <footer><span>DECIDE! <b>1.0.0</b></span><span>Feito para acabar com a indecisão.</span></footer>
  </main>`;

function setCategory(name) {
  selected = name;
  document.querySelector('#options').value = categories[name].join('\n');
  document.querySelectorAll('[data-category]').forEach(b=>b.classList.toggle('chosen', b.dataset.category===name));
  hideResult();
}
function hideResult(){ document.querySelector('#result').classList.add('hidden'); lastResult=''; }
function renderHistory(){
  const el=document.querySelector('#history');
  el.innerHTML=history.length ? history.slice(0,6).map(x=>`<div class="history-row"><span>${escapeHtml(x.category)}</span><b>${escapeHtml(x.value)}</b></div>`).join('') : '<div class="empty">Seus resultados aparecerão aqui.</div>';
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function spin(){
  const options=document.querySelector('#options').value.split('\n').map(x=>x.trim()).filter(Boolean);
  if(options.length<2){alert('Adicione pelo menos duas opções.');return;}
  const winner=options[Math.floor(Math.random()*options.length)];
  lastResult=winner;
  document.querySelector('#winner').textContent=winner;
  document.querySelector('#result').classList.remove('hidden');
  history.unshift({category:selected,value:winner,date:new Date().toISOString()});
  history=history.slice(0,30);localStorage.setItem('decide-history',JSON.stringify(history));renderHistory();
}
function showTab(tab){
  document.querySelectorAll('.panel[id]').forEach(p=>p.classList.toggle('hidden',p.id!==tab));
  document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.tab===tab));
}
document.querySelectorAll('[data-category]').forEach(b=>b.addEventListener('click',()=>setCategory(b.dataset.category)));
document.querySelectorAll('[data-tab]').forEach(b=>b.addEventListener('click',()=>showTab(b.dataset.tab)));
document.querySelector('#spin').addEventListener('click',spin);
document.querySelector('#again').addEventListener('click',spin);
document.querySelector('#save').addEventListener('click',()=>{
  if(!lastResult)return;
  if(!favorites.includes(lastResult))favorites.push(lastResult);
  localStorage.setItem('decide-favorites',JSON.stringify(favorites));
  document.querySelector('#save').textContent='♥ Salvo';
});
document.querySelector('#clear-history').addEventListener('click',()=>{history=[];localStorage.setItem('decide-history','[]');renderHistory();});
document.querySelectorAll('[data-idea]').forEach(b=>b.addEventListener('click',()=>{
  const out=document.querySelector('#couple-output');out.textContent=ideaFor(b.dataset.idea);out.classList.remove('hidden');
}));

const adultPositions = [
  {name:'Missionário', difficulty:'Fácil', toy:'Qualquer'},
  {name:'Papai e mamãe', difficulty:'Fácil', toy:'Qualquer'},
  {name:'Conchinha', difficulty:'Fácil', toy:'Qualquer'},
  {name:'De lado', difficulty:'Fácil', toy:'Qualquer'},
  {name:'Sentados frente a frente', difficulty:'Intermediária', toy:'Qualquer'},
  {name:'Lótus', difficulty:'Intermediária', toy:'Qualquer'},
  {name:'Cadeira', difficulty:'Intermediária', toy:'Qualquer'},
  {name:'Em pé', difficulty:'Avançada', toy:'Qualquer'},
  {name:'De quatro', difficulty:'Intermediária', toy:'Qualquer'},
  {name:'Arco', difficulty:'Avançada', toy:'Qualquer'},
  {name:'Ponte', difficulty:'Avançada', toy:'Qualquer'},
  {name:'Colher invertida', difficulty:'Intermediária', toy:'Qualquer'},
  {name:'Cruz', difficulty:'Intermediária', toy:'Qualquer'},
  {name:'Tesoura', difficulty:'Avançada', toy:'Qualquer'},
  {name:'Andrômaca', difficulty:'Intermediária', toy:'Qualquer'},
  {name:'Vaquera reversa', difficulty:'Intermediária', toy:'Qualquer'},
  {name:'União suspensa', difficulty:'Avançada', toy:'Qualquer'},
  {name:'União do elefante', difficulty:'Intermediária', toy:'Qualquer'},
  {name:'União do lobo', difficulty:'Avançada', toy:'Qualquer'},
  {name:'União do tigre', difficulty:'Avançada', toy:'Qualquer'}
];
function renderPositions(){
  const target=document.querySelector('#positions-list');
  if(!target) return;
  const difficulty=document.querySelector('#difficulty-filter').value;
  const toy=document.querySelector('#toy-filter').value;
  const filtered=adultPositions.filter(p=>(difficulty==='Todas'||p.difficulty===difficulty));
  target.innerHTML=filtered.map((p,i)=>`<div class="position-row"><div><b>${i+1}. ${escapeHtml(p.name)}</b><small>${p.difficulty}</small></div><span class="position-tag">${toy==='Sim'?'Acessório opcional':toy==='Não'?'Sem acessório':'Livre escolha'}</span></div>`).join('');
}
document.querySelector('#difficulty-filter')?.addEventListener('change',renderPositions);
document.querySelector('#toy-filter')?.addEventListener('change',renderPositions);
renderPositions();

function ideaFor(kind){
 const ideas={
  'Perguntas para se conhecer melhor':'Perguntem um ao outro: qual experiência você gostaria muito de viver comigo? O que faz você se sentir mais amado(a)? Qual lembrança nossa sempre te faz sorrir?',
  'Desafios românticos':'Desafio: cada pessoa prepara uma surpresa simples para a outra, sem gastar dinheiro. Vale música, bilhete, carinho ou uma lembrança especial.',
  'Noite de conexão':'Escolham uma música de cada fase do relacionamento, preparem algo para comer e contem por que cada música foi escolhida.',
  'Desafios adultos consensuais':'Conversem primeiro sobre limites e vontades. Cada pessoa pode sugerir uma experiência, dizer sim, não ou propor uma alternativa. Ninguém deve se sentir pressionado.'
 };return ideas[kind];
}
document.querySelector('#ask').addEventListener('submit',async e=>{
 e.preventDefault();const prompt=document.querySelector('#prompt');const text=prompt.value.trim();if(!text)return;
 addBubble(text,'user');prompt.value='';
 const loading=addBubble('Pensando...','bot');
 try{
  const res=await fetch('/api/assistant',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({message:text,context:{category:selected}})});
  if(!res.ok)throw new Error('IA ainda não configurada no servidor.');
  const data=await res.json();loading.textContent=data.reply||'Não consegui gerar uma resposta.';
 }catch(err){loading.textContent='A IA ainda não está conectada. Para ativá-la, configure o servidor descrito no README. A roleta continua funcionando offline. (Detalhe: '+err.message+')';}
});
function addBubble(text,who){const el=document.createElement('div');el.className='bubble '+who;el.textContent=text;document.querySelector('#chat').append(el);el.scrollIntoView({behavior:'smooth',block:'nearest'});return el;}
renderHistory();
if('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('/sw.js').catch(()=>{});
